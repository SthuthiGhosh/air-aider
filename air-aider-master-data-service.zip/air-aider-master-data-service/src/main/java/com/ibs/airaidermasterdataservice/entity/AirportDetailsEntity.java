/**
 * 
 */
package com.ibs.airaidermasterdataservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ibs.airaidermasterdataservice.util.LanguageCodeConstants;

/**
 * @author 91940
 *
 */
@Entity
@Table(name = "AIR_AIDER_AIRPORT_DETAILS")
public class AirportDetailsEntity {
	
	@Id
	@Column(name="AIRPORT_DETAIL_ID")
	private int airportdDetailId;
	
	@Column(name="AIRPORT_ID")
	private int airportId;
	@Column(name="AIRPORT_NAME")
	private String airportName;
	
	@Enumerated(EnumType.STRING)
	private LanguageCodeConstants languageCodeConstants;
	/**
	 * @return the airportdDetailId
	 */
	public int getAirportdDetailId() {
		return airportdDetailId;
	}
	/**
	 * @param airportdDetailId the airportdDetailId to set
	 */
	public void setAirportdDetailId(int airportdDetailId) {
		this.airportdDetailId = airportdDetailId;
	}
	/**
	 * @return the airportId
	 */
	public int getAirportId() {
		return airportId;
	}
	/**
	 * @param airportId the airportId to set
	 */
	public void setAirportId(int airportId) {
		this.airportId = airportId;
	}
	/**
	 * @return the airportName
	 */
	public String getAirportName() {
		return airportName;
	}
	/**
	 * @param airportName the airportName to set
	 */
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
}
