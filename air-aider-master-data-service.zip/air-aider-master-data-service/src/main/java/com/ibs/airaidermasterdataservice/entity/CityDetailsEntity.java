/**
 * 
 */
package com.ibs.airaidermasterdataservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.ibs.airaidermasterdataservice.util.LanguageCodeConstants;

/**
 * @author 91940
 *
 */
@Entity
@Table(name = "AIR_AIDER_CITY_DETAILS")
public class CityDetailsEntity {

	@Id
	@Column(name = "CITY_DETAIL_ID")
	private int cityDetailId;

	@Column(name = "CITY_ID")
	private int cityId;
	@Column(name = "CITY_NAME")
	private String cityName;
	
	@Enumerated(EnumType.STRING)
	private LanguageCodeConstants languageCodeConstants;

	/**
	 * @return the cityDetailId
	 */
	public int getCityDetailId() {
		return cityDetailId;
	}

	/**
	 * @param cityDetailId the cityDetailId to set
	 */
	public void setCityDetailId(int cityDetailId) {
		this.cityDetailId = cityDetailId;
	}

	/**
	 * @return the cityId
	 */
	public int getCityId() {
		return cityId;
	}

	/**
	 * @param cityId the cityId to set
	 */
	public void setCityId(int cityId) {
		this.cityId = cityId;
	}

	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

}
