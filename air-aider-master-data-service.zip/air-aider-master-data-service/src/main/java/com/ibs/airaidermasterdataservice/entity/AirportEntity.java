/**
 * 
 */
package com.ibs.airaidermasterdataservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.ibs.airaidermasterdataservice.util.AirportCodeConstants;

/**
 * @author Sthuthi
 *
 */
@Entity
@Table(name = "AIR_AIDER_AIRPORT")
public class AirportEntity {

	@Id
	@Column(name = "AIRPORT_ID")
	private int airportId;
	@Column(name = "CITY_ID")
	private int cityId;
	
	@Enumerated(EnumType.STRING)
	private AirportCodeConstants airportCodeConstants;

	/**
	 * @return the airportId
	 */
	public int getAirportId() {
		return airportId;
	}

	/**
	 * @param airportId the airportId to set
	 */
	public void setAirportId(int airportId) {
		this.airportId = airportId;
	}

	/**
	 * @return the cityId
	 */
	public int getCityId() {
		return cityId;
	}

	/**
	 * @param cityId the cityId to set
	 */
	public void setCityId(int cityId) {
		this.cityId = cityId;
	}
}
