/**
 * 
 */
package com.ibs.airaidermasterdataservice.util;

/**
 * @author 91940
 *
 */
public enum CityCodeConstants {

}
